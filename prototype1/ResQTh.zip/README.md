# ResQTh · full prototype

Clickable prototype of **ResQTh**, an emergency-help app for visitors in Thailand.
It runs entirely in the browser (no build step, no server) and supports **English and Thai**.

> All data is sample data. Nothing is saved or sent.

## Files

| File         | What it contains                                              |
| ------------ | ------------------------------------------------------------- |
| `index.html` | Page structure: demo controls, the two phone mock-ups, toast  |
| `style.css`  | All styles for the page and the phone screens                 |
| `script.js`  | Data (categories, keywords, stations), screens, and logic     |
| `README.md`  | This file                                                     |

Keep the four files in the same folder. `index.html` loads `style.css` and `script.js` by relative path.

## How to run

Open `index.html` in a browser (double-click is enough).
An internet connection is only needed for the Google Font (IBM Plex Sans Thai); without it the page falls back to system fonts.

## What the prototype covers

- **FR-1** – Allow location (coordinates stay on the phone and are used to find the nearest station), or choose a province if you say no.
- **FR-2** – Browse categories, see the urgency tag, clear the filter.
- **FR-3** – High-urgency call screen, or low-urgency case pack.
- **FR-4** – Type a sentence, check the guessed category, change it.
- **FR-5** – Live link to a trusted contact, with auto-delete.
- **Language** – Tap the language button at the top to switch between English and Thai.
- **Concept only** – "Emergency services see it" needs a partnership and is outside the current SRS.

## Demo controls (top of the page)

- **Which phone** – switch between *Sam's phone* (person in an emergency) and *Alex's phone* (trusted contact).
- **Speed** – 1×, 30×, or 300× demo clock.
- **Network** – Online / Offline, to show the offline behaviour.
- **Reset** – return the demo to its starting state.

The demo clock and position are simulated; the position follows the province you pick.

## Editing tips

- Change colors and layout in `style.css`.
- Change categories, keywords, and station data at the top of `script.js` (the `CATS` object and the data below it).
- Change the page text outside the phones (demo bar, "What this prototype covers") in `index.html`.

## Context

Part of the Intro to Software Engineering team project (ResQTh, Mae Fah Luang University).
